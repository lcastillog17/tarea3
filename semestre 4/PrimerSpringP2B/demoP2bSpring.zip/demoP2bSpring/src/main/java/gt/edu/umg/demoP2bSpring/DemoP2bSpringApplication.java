package gt.edu.umg.demoP2bSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoP2bSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoP2bSpringApplication.class, args);
	}

}
